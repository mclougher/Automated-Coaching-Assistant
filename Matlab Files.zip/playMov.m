function [ M ] = playMov( F )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

M=F;


        movie(M,1,30)

end

