function [  ] = testAri( num )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

num

end

