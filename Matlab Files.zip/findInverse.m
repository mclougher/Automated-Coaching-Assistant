function [ a,h,k ] = findInverse( a, b, c )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here

    h=-b/(2*a);
    k=c-(b*b)/(4*a);
    
    
end

