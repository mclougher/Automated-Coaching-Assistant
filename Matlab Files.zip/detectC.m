function [ c ] = detectC(a,b )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here


c=a*b;

cImg=imread('C:\Users\Michael\Pictures\KinectSnapshot-09-01-46.bmp');
figure
image(cImg);



end

